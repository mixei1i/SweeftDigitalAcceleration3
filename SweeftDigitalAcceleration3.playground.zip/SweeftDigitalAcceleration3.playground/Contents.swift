import UIKit
import Foundation

/* 1.     დაწერეთ ფუნქცია, რომელსაც გადაეცემა ტექსტი  და აბრუნებს პალინდრომია თუ არა. (პალინდრომი არის ტექსტი რომელიც ერთნაირად იკითხება ორივე მხრიდან).
Boolean isPalindrome(String text); */

func isPalindrom(_ text: String) -> Bool {
    var newText = ""
    for i in text {
        newText.append(i.uppercased())
    }
    print(newText)
   return newText == String(newText.reversed())
}

print(isPalindrom("1.AbBA.1"))


 
 /* 2.     გვაქვს 1,5,10,20 და 50 თეთრიანი მონეტები. დაწერეთ ფუნქცია, რომელსაც გადაეცემა თანხა (თეთრებში) და აბრუნებს მონეტების მინიმალურ რაოდენობას, რომლითაც შეგვიძლია ეს თანხა დავახურდაოთ.

Int minSplit(Int amount); */


func minSplit(_ amount: Int) -> Int {
    let numb = amount
              var temp = 0
    let a = numb / 50
              temp = numb % 50
    let b = temp / 20
              temp = temp % 20
    let c = temp / 10
              temp = temp % 10
    let d = temp / 5
              temp = temp % 5
    let e = temp / 1
              return a + b + c + d + e
}

print(minSplit(89))


 /* 3.     მოცემულია მასივი, რომელიც შედგება მთელი რიცხვებისგან. დაწერეთ ფუნქცია რომელსაც გადაეცემა ეს მასივი და აბრუნებს მინიმალურ მთელ რიცხვს, რომელიც 0-ზე მეტია და ამ მასივში არ შედის.

Int notContains(Int[] array); */



func notContains(array: [Int]) -> Int {
    let maxElement = array.max() ?? 0
    if maxElement >= 1 {
    for i in 1...maxElement + 1 {
        //print(i)
        if array.contains(i){
            continue
        } else {
            return i
        }
    }
    }
    return 1
    
}
print(notContains(array: [1]))


 /* 4.     მოცემულია String რომელიც შედგება „(„ და „)“ ელემენტებისგან. დაწერეთ ფუნქცია რომელიც აბრუნებს ფრჩხილები არის თუ არა მათემატიკურად სწორად დასმული.

Boolean isProperly(String sequence);

მაგ: (()()) სწორი მიმდევრობაა,  ())() არასწორია  */


func isProperly(_ string: String) -> Bool {
    var corect = 0
    for bracket in string {
        if bracket == "(" {
            corect += 1
        } else if bracket == ")" {
            if (corect == 0) {
                return false
            } else {
                corect -= 1
            }
        }
    }
    let result = (corect == 0)
    return result
}
print(isProperly("(())"))
print(isProperly("())()"))




 /* 5.     გვაქვს n სართულიანი კიბე, ერთ მოქმედებაში შეგვიძლია ავიდეთ 1 ან 2 საფეხურით. დაწერეთ ფუნქცია რომელიც დაითვლის n სართულზე ასვლის ვარიანტების რაოდენობას.

Int countVariants(Int stearsCount);  */


func countVariants(stearsCount: Int) -> Int {
    let n = stearsCount
    let k = 2 // 1 & 2
    var comb = 0
  func fact(_ a: Int) -> Int {
        if a == 0 {
            return 1
        } else {
            return a * fact(a - 1)
        }
    }
    
    if n == 0 || n == 1 || n == 2 {
      return n
    } else {
        comb = fact(n) / (fact(k) * fact(n - k))
      return comb - (n - 3)}
    }


print(countVariants(stearsCount: 1))
print(countVariants(stearsCount: 2))
print(countVariants(stearsCount: 3))
print(countVariants(stearsCount: 4))
print(countVariants(stearsCount: 5))
print(countVariants(stearsCount: 6))
print(countVariants(stearsCount: 7))



/* 5.2  */

func countVariants2(stearsCount: Int) -> Int {
    var newSec = [1,2]
    if stearsCount == 0 || stearsCount == 1 || stearsCount == 2 {
        return stearsCount
    } else {
    for n in 3...stearsCount {
        newSec.append(newSec[n - 2] + n - 2)
        
    }
    return newSec.max() ?? 0
    }
}

var testCountVariant = countVariants2(stearsCount: 6)
print(testCountVariant)





 /* 6.     დაწერეთ საკუთარი მონაცემთა სტრუქტურა, რომელიც საშუალებას მოგვცემს O(1) დროში წავშალოთ ელემენტი.
  
  - Complexity: Amortized O(1) if the set does not wrap a bridged `NSSet`.
  ///   If the set wraps a bridged `NSSet`, the performance is unspecified.
  ///
  /// - Returns: A member of the set.
  @inlinable public mutating func removeFirst() -> Element
*/

 struct own {
     var country: Set = ["Greece", "Spain"]

}

var remFirst = own()
remFirst.country.removeFirst()    // O(1)
print(remFirst.country)







